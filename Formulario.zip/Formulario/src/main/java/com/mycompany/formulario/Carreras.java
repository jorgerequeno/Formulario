/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.formulario;

/**
 *
 * @author FRIDA KALO
 */
public class Carreras extends Alumno {

private double carrera;

    public Carreras() {
        }

    public Carreras(double carrera) {
        this.carrera = carrera;
    }

    public void setCarrera(double carrera) {
        this.carrera = carrera;
    }

    public double getCarrera() {
        return carrera;
    }


}
    

